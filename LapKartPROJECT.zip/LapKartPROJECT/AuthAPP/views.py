from django.shortcuts import render,redirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate,login,logout
from django.contrib import messages
# Create your views here.

def registerview(request):
    if request.method == "GET":
        form = UserCreationForm()
        template_name = "AuthAPP/register.html"
        context ={"form":form}
        return render(request, template_name, context)
    elif request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("/auth/login/")

def loginview(request):
    if request.method == "POST":
        u = request.POST["un"]
        p = request.POST["pw"]
        user = authenticate(username=u, password=p)
        if user is not None:
            login(request,user)
            return redirect("/laptops/show/")
        else:
            messages.add_message(request,messages.ERROR,"Invalid Credentials")
    template_name = "AuthAPP/login.html"
    context = {}
    return render(request, template_name, context)

def logoutview(request):
    logout(request)
    return redirect("/auth/login/")