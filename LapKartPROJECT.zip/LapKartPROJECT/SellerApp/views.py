from django.shortcuts import render,redirect
from .forms import LaptopModelForm
from .models import LaptopModel
from django.contrib.auth.decorators import login_required
# Create your views here.
@login_required(login_url="/auth/login/")
def showlaptopsview(request):
    laptop_objects = LaptopModel.objects.all()
    template_name = "SellerApp/show_laptops.html"
    context ={"laptop_objects":laptop_objects}
    return render(request, template_name, context)

@login_required(login_url="/auth/login/")
def addlaptopsview(request):
    '''
    form = LaptopModelForm()
    if request.method == "POST":
        form = LaptopModelForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect("/laptops/show/")
    template_name = "SellerApp/add_laptops.html"
    context = {"form": form}
    return render(request, template_name, context)
    '''
    if request.method == "GET":
        form = LaptopModelForm()
        template_name = "SellerApp/add_laptops.html"
        context = {"form":form}
        return render(request, template_name, context)
    elif request.method == "POST":
        form = LaptopModelForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()
            return redirect("/laptops/show/")

@login_required(login_url="/auth/login/")
def updatelaptopsview(request,i):
    lap_to_be_updated = LaptopModel.objects.get(id=i)
    if request.method == "GET":
        form = LaptopModelForm(instance=lap_to_be_updated)
        template_name = "SellerApp/add_laptops.html"
        context = {"form": form}
        return render(request, template_name, context)
    elif request.method == "POST":
        form = LaptopModelForm(request.POST, request.FILES, instance=lap_to_be_updated)
        if form.is_valid():
            form.save()
            return redirect("/laptops/show/")

@login_required(login_url="/auth/login/")
def deletelaptopsview(request,i):
    lap_to_be_deleted = LaptopModel.objects.get(id=i)
    lap_to_be_deleted.delete()
    return redirect("/laptops/show/")