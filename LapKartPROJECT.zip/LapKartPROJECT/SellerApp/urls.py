from django.urls import path
from . import views

urlpatterns=[
    path('show/',views.showlaptopsview),
    path('add/',views.addlaptopsview),
    path('update/<i>/',views.updatelaptopsview),
    path('delete/<i>/',views.deletelaptopsview),
]